﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Lab3_CNPM;
using Lab3_CNPM.Models;

namespace Lab3_CNPM.Controllers
{
    public class LaptopsController : Controller
    {
        private LaptopDAO dao = new LaptopDAO(new LaptopContext());

        // GET: Laptops
        public ActionResult List()
        {
            return View(dao.GetAll());
        }

    }
}
