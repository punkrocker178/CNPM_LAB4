﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Lab3_CNPM.Models
{
    public class Laptop
    {
        public string ID { get; set; }
        [Required]
        [MaxLength(128)]
        public string Name { get; set; }
        [Required]
        public int Price { get; set; }
        public string CPU { get; set; }
        public int RAM { get; set; }
        public int Storage { get; set; }
    }
}