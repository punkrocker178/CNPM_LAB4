﻿using Lab3_CNPM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab3_CNPM
{
    public class LaptopDAO
    {
        private LaptopContext db;
        public LaptopDAO(LaptopContext context)
        {
            this.db = context;
        }

        public IEnumerable<Laptop> GetAll()
        {
            return db.Laptops;
        }

        public void AddLaptop(Laptop lap)
        {
            db.Laptops.Add(lap);
            db.SaveChanges();
        }
    }
}